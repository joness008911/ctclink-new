import { motion } from 'motion/react';
import { 
  ShieldCheck, 
  Globe, 
  Activity, 
  Code, 
  Zap, 
  CheckCircle2, 
  ChevronRight, 
  Menu,
  Cloud,
  Layers,
  Hexagon,
  Anchor,
  Cpu,
  Beaker,
  Search,
  Settings,
  Bot,
  Network,
  ShieldAlert,
  Ghost,
  MapPin,
  Lock,
  LineChart,
  Globe,
  FileCode2,
  Fingerprint,
  Activity,
  ShieldCheck,
  CheckSquare,
  Info,
  Wallet,
  SlidersHorizontal,
  PieChart,
  Target,
  ArrowRight
} from 'lucide-react';

export default function App() {
  return (
    <div className="min-h-screen flex flex-col overflow-x-hidden selection:bg-indigo-500/30">
      {/* Navigation */}
      <nav className="w-full z-50 bg-[#161616]">
        <div className="max-w-[1400px] mx-auto px-6 lg:px-10 h-20 md:h-24 flex items-center justify-between">
          <div className="flex items-center gap-12">
            <div className="flex items-center gap-2">
              <ShieldCheck className="w-7 h-7 text-white" />
              <span className="font-sans font-medium text-xl text-white tracking-tight">EdgeGuard</span>
            </div>
            <div className="hidden md:flex items-center gap-8">
              <a href="#features" className="text-[15px] font-medium text-[#a1a1a1] hover:text-white transition-colors">Features</a>
              <a href="#how-it-works" className="text-[15px] font-medium text-[#a1a1a1] hover:text-white transition-colors">Integration</a>
              <a href="#pricing" className="text-[15px] font-medium text-[#a1a1a1] hover:text-white transition-colors">Pricing</a>
            </div>
          </div>
          <div className="hidden md:flex items-center gap-6">
            <button className="text-[15px] font-medium text-[#a1a1a1] hover:text-white transition-colors">Log in</button>
            <button className="text-[15px] font-medium bg-white text-black px-6 py-2.5 rounded-full hover:bg-gray-100 transition-colors">
              Get Started
            </button>
          </div>
          <button className="md:hidden text-[#a1a1a1]">
            <Menu className="w-6 h-6" />
          </button>
        </div>
      </nav>

      {/* Hero Section */}
      <section className="bg-[#161616] px-3 md:px-4 pb-8 md:pb-12 pt-3 md:pt-4">
        <div className="max-w-[1400px] mx-auto rounded-[2rem] md:rounded-[2.5rem] overflow-hidden relative flex flex-col" style={{
          background: 'radial-gradient(100% 100% at 0% 0%, #c1e0c8 0%, transparent 100%), radial-gradient(100% 100% at 100% 0%, #c9e6f0 0%, transparent 100%), radial-gradient(100% 100% at 100% 100%, #e8d5ec 0%, transparent 100%), radial-gradient(100% 100% at 0% 100%, #d5e5d3 0%, transparent 100%), #eaf1eb'
        }}>
          <div className="w-full px-6 pt-16 pb-0 md:px-8 md:py-20 lg:px-16 lg:pt-32 flex flex-col lg:flex-row justify-between gap-8 lg:gap-12 items-start lg:items-end flex-1 min-h-[85vh] md:min-h-[700px]">
            <div className="max-w-[700px] pb-8 md:pb-16 lg:pb-24 mt-auto lg:mt-0">
              <motion.div
                initial={{ opacity: 0, y: 20 }}
                animate={{ opacity: 1, y: 0 }}
                transition={{ duration: 0.5 }}
              >
                <h1 className="text-[2.75rem] md:text-[3.5rem] leading-[1.1] lg:text-[5.5rem] lg:leading-[1.05] font-sans font-medium tracking-tight text-[#000000] mb-6 md:mb-8" style={{ WebkitFontSmoothing: 'antialiased' }}>
                  Protect your infrastructure with intelligent routing.
                </h1>
                <p className="text-lg lg:text-[1.35rem] text-[#4a4a4a] mb-8 md:mb-10 max-w-[600px] leading-relaxed">
                  Enterprise-grade IP geolocation, VPN/Proxy detection, and real-time bot mitigation. Integrate in minutes via PHP snippet, WordPress plugin, or API.
                </p>
                <div className="flex flex-col sm:flex-row items-center gap-4">
                  <button className="w-full sm:w-auto px-8 py-4 bg-[#161616] hover:bg-black text-white rounded-full font-medium transition-all text-[15px] flex items-center justify-center gap-2 group">
                    Start Free Trial
                    <ChevronRight className="w-4 h-4 group-hover:translate-x-1 transition-transform" />
                  </button>
                  <button className="w-full sm:w-auto px-8 py-4 bg-white/40 hover:bg-white/60 text-[#161616] rounded-full font-medium transition-all backdrop-blur-sm text-[15px] flex items-center justify-center gap-2">
                    <Code className="w-4 h-4" />
                    View Documentation
                  </button>
                </div>
              </motion.div>
            </div>
            
            <div className="block w-full lg:w-[450px] relative self-end mt-8 lg:mt-0">
              <img 
                src="https://images.unsplash.com/photo-1522071820081-009f0129c71c?ixlib=rb-4.0.3&auto=format&fit=crop&w=800&q=80" 
                alt="Team analyzing data" 
                className="w-full h-[250px] md:h-[350px] lg:h-auto object-cover rounded-t-2xl lg:rounded-t-none lg:rounded-tl-3xl shadow-2xl border-t border-x lg:border-r-0 lg:border-x-0 lg:border-l border-white/40"
              />
            </div>
          </div>

          {/* Trusted By Marquee */}
          <div className="py-6 md:py-8 bg-[#111111] border-y border-white/5 flex flex-col md:flex-row items-center justify-center lg:justify-start overflow-hidden">
            <div className="px-6 md:pl-10 md:pr-8 z-20 shrink-0 mb-8 md:mb-0 flex items-center justify-center">
              <span className="text-white/50 font-medium text-sm md:text-[15px] uppercase tracking-[0.2em]">Trusted by</span>
              <div className="hidden md:block w-px h-8 bg-white/10 ml-8"></div>
            </div>

            <div className="relative flex overflow-hidden w-full flex-1" style={{ maskImage: 'linear-gradient(to right, transparent, black 10%, black 90%, transparent)', WebkitMaskImage: 'linear-gradient(to right, transparent, black 10%, black 90%, transparent)' }}>
              <div className="flex shrink-0 animate-marquee items-center gap-16 md:gap-24 pr-16 md:pr-24">
                {[
                  { icon: Cloud, name: 'CloudScale' },
                  { icon: Layers, name: 'StackSync' },
                  { icon: Hexagon, name: 'Nexus' },
                  { icon: Anchor, name: 'Harbor' },
                  { icon: Cpu, name: 'CyberCore' },
                  { icon: Zap, name: 'Bolt' },
                  { icon: Beaker, name: 'Labs' },
                ].map((logo, i) => (
                  <div key={i} className="flex items-center gap-3 text-white/40 hover:text-white/80 transition-colors duration-300">
                    <logo.icon className="w-7 h-7 md:w-8 md:h-8" />
                    <span className="font-sans font-bold text-lg md:text-xl tracking-tight">{logo.name}</span>
                  </div>
                ))}
              </div>
              <div className="flex shrink-0 animate-marquee items-center gap-16 md:gap-24 pr-16 md:pr-24" aria-hidden="true">
                {[
                  { icon: Cloud, name: 'CloudScale' },
                  { icon: Layers, name: 'StackSync' },
                  { icon: Hexagon, name: 'Nexus' },
                  { icon: Anchor, name: 'Harbor' },
                  { icon: Cpu, name: 'CyberCore' },
                  { icon: Zap, name: 'Bolt' },
                  { icon: Beaker, name: 'Labs' },
                ].map((logo, i) => (
                  <div key={`dup-${i}`} className="flex items-center gap-3 text-white/40 hover:text-white/80 transition-colors duration-300">
                    <logo.icon className="w-7 h-7 md:w-8 md:h-8" />
                    <span className="font-sans font-bold text-lg md:text-xl tracking-tight">{logo.name}</span>
                  </div>
                ))}
              </div>
            </div>
          </div>

          {/* Stop the Bad Traffic Section */}
          <div className="py-16 md:py-24 px-6 md:px-8 lg:px-16 border-t border-black/5">
            <div className="w-full max-w-[750px]">
              <motion.div
                initial={{ opacity: 0, y: 20 }}
                whileInView={{ opacity: 1, y: 0 }}
                viewport={{ once: true }}
                transition={{ duration: 0.6 }}
              >
                <h2 className="text-3xl md:text-5xl lg:text-[3.5rem] font-sans font-medium text-black mb-8 tracking-tight leading-[1.1]">
                  Stop the Bad Traffic Before It Reaches Your Website
                </h2>
                
                <div className="space-y-6 text-[#4a4a4a] text-lg lg:text-[1.15rem] leading-relaxed mb-10">
                  <p>
                    Go beyond traditional CAPTCHA protection. As automated threats become more sophisticated, some bots can bypass or solve CAPTCHA challenges.
                  </p>
                  <p>
                    BotShield takes a smarter approach by analyzing every visitor using advanced multi-layer detection—including IP intelligence, browser fingerprinting, HTTP request analysis, browser integrity checks, and behavioral analytics—to accurately identify and stop malicious bots, scrapers, AI crawlers, VPNs, proxies, datacenter traffic, and other automated threats before they reach your website.
                  </p>
                  <p>
                    Protect your website, preserve accurate analytics, reduce abuse, and keep legitimate visitors moving without friction.
                  </p>
                </div>
                
                <button className="w-full sm:w-auto px-8 py-4 bg-[#161616] hover:bg-black text-white rounded-full font-medium transition-all text-[15px] flex items-center justify-center gap-2 group">
                  Get Started for Free
                  <ChevronRight className="w-4 h-4 group-hover:translate-x-1 transition-transform" />
                </button>
              </motion.div>
            </div>
          </div>

          {/* Keep Your Resources Focused Section */}
          <div className="py-16 md:py-24 px-6 md:px-8 lg:px-16 border-t border-black/5">
            <div className="w-full">
              <motion.div
                initial={{ opacity: 0, y: 20 }}
                whileInView={{ opacity: 1, y: 0 }}
                viewport={{ once: true }}
                transition={{ duration: 0.6 }}
                className="max-w-[800px] mb-16 md:mb-20"
              >
                <h2 className="text-3xl md:text-5xl lg:text-[3.5rem] font-sans font-medium text-black mb-8 tracking-tight leading-[1.1]">
                  Keep Your Resources Focused on Real Visitors
                </h2>
                <p className="text-[#4a4a4a] text-lg lg:text-[1.15rem] leading-relaxed">
                  Block malicious traffic before it consumes bandwidth, API requests, database resources, and server capacity—so your infrastructure stays optimized for genuine users. Reduce unnecessary costs, improve application performance, and ensure legitimate visitors always receive the best experience.
                </p>
              </motion.div>

              <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-x-8 gap-y-12 md:gap-y-16">
                {[
                  { icon: Settings, title: 'Automation Tools', desc: 'Detect and block automated browsers, scraping tools, and bots used for form submissions, data harvesting, and large-scale automation.' },
                  { icon: Network, title: 'Botnets', desc: 'Identify coordinated networks of malicious bots before they can launch attacks, abuse resources, or overwhelm your infrastructure.' },
                  { icon: ShieldAlert, title: 'Fraud Prevention', desc: 'Stop suspicious traffic linked to payment fraud, account takeovers, fake signups, credential stuffing, and other forms of online abuse.' },
                  { icon: Ghost, title: 'VPNs & Proxies', desc: 'Detect visitors attempting to conceal their identity or location through VPNs, proxies, Tor networks, and anonymous infrastructure.' },
                  { icon: Bot, title: 'AI Crawlers & Web Crawlers', desc: 'Control automated crawlers that collect, index, or scrape your website content without permission, helping protect your data and infrastructure.' },
                  { icon: MapPin, title: 'IP Intelligence', desc: 'Leverage rich IP intelligence—including reputation, geolocation, ASN, hosting provider, usage type, and risk signals—to make smarter security decisions in real time.' },
                  { icon: Lock, title: 'Cybersecurity', desc: 'Strengthen your security posture by identifying high-risk traffic early, reducing attack surfaces, and preventing malicious requests before they reach your applications.' },
                  { icon: LineChart, title: 'Performance & Cost Optimization', desc: 'Reduce unnecessary server load, bandwidth consumption, API calls, and database operations, ensuring your infrastructure remains dedicated to legitimate users.' },
                ].map((feature, i) => (
                  <motion.div
                    key={i}
                    initial={{ opacity: 0, y: 20 }}
                    whileInView={{ opacity: 1, y: 0 }}
                    viewport={{ once: true }}
                    transition={{ duration: 0.5, delay: i * 0.1 }}
                    className="flex flex-col group cursor-default"
                  >
                    <div className="w-12 h-12 rounded-[14px] bg-black/5 flex items-center justify-center mb-6 text-black/70 group-hover:bg-black group-hover:text-white transition-colors duration-300">
                      <feature.icon className="w-6 h-6" />
                    </div>
                    <h3 className="text-xl font-bold text-black mb-3 tracking-tight">
                      {feature.title}
                    </h3>
                    <p className="text-[#4a4a4a] leading-relaxed text-[15px]">
                      {feature.desc}
                    </p>
                  </motion.div>
                ))}
              </div>

              <motion.div 
                initial={{ opacity: 0, y: 20 }}
                whileInView={{ opacity: 1, y: 0 }}
                viewport={{ once: true }}
                transition={{ duration: 0.6, delay: 0.2 }}
                className="mt-20 md:mt-24 flex flex-col items-center text-center"
              >
                <button className="px-8 py-4 bg-[#161616] hover:bg-black text-white rounded-full font-medium transition-all text-[15px] flex items-center justify-center gap-2 group shadow-md shadow-black/5">
                  Get Started for Free
                  <ChevronRight className="w-4 h-4 group-hover:translate-x-1 transition-transform" />
                </button>
                <p className="mt-5 text-sm font-medium text-[#4a4a4a]">
                  Start protecting your website in minutes. No credit card required.
                </p>
              </motion.div>
            </div>
          </div>

          {/* Our Detection Engine Section */}
          <div className="bg-[#0A0A0A] py-16 md:py-20 px-6 relative overflow-hidden">
            {/* Animated Background Beams */}
            <div className="absolute inset-0 pointer-events-none">
              <div className="absolute top-0 left-1/2 -translate-x-1/2 w-full h-full max-w-[1200px] opacity-40 mix-blend-screen">
                <div className="absolute top-0 left-[10%] w-[1px] h-[150%] bg-gradient-to-b from-transparent via-[#FFB300]/30 to-transparent animate-beam"></div>
                <div className="absolute top-0 left-[45%] w-[1px] h-[150%] bg-gradient-to-b from-transparent via-indigo-500/30 to-transparent animate-beam-slow"></div>
                <div className="absolute top-0 left-[85%] w-[1px] h-[150%] bg-gradient-to-b from-transparent via-white/20 to-transparent animate-beam-fast"></div>
              </div>
              <div className="absolute inset-0 bg-[radial-gradient(circle_at_top_right,rgba(255,179,0,0.03),transparent_50%)]"></div>
              <div className="absolute inset-0 bg-[radial-gradient(circle_at_bottom_left,rgba(99,102,241,0.03),transparent_50%)]"></div>
              {/* Subtle Grid overlay */}
              <div className="absolute inset-0 bg-[linear-gradient(to_right,#ffffff02_1px,transparent_1px),linear-gradient(to_bottom,#ffffff02_1px,transparent_1px)] bg-[size:32px_32px]"></div>
            </div>

            <div className="max-w-[1400px] mx-auto relative z-10">
              <div className="mb-12 md:mb-16">
                <motion.div
                  initial={{ opacity: 0, y: 20 }}
                  whileInView={{ opacity: 1, y: 0 }}
                  viewport={{ once: true }}
                  transition={{ duration: 0.6 }}
                >
                  <span className="block text-white/70 uppercase text-sm md:text-base font-bold tracking-[0.1em] mb-2 md:mb-3">
                    Advanced Multi-Layer Detection
                  </span>
                  <h2 className="text-4xl md:text-5xl lg:text-6xl font-sans font-black uppercase leading-[0.9] tracking-tighter mb-6">
                    <span className="text-white block">Our Detection</span>
                    <span className="text-[#FFB300] block">Engine</span>
                  </h2>
                  <p className="text-base md:text-lg text-[#a1a1a1] leading-relaxed max-w-3xl font-medium">
                    Every visitor is evaluated through multiple independent detection layers—not just a single signal. By combining network intelligence, browser fingerprinting, request analysis, behavioral analytics, and continuously updated threat intelligence, BotShield accurately distinguishes legitimate users from sophisticated automated traffic in real time.
                  </p>
                </motion.div>
              </div>

              {/* Grid of layers */}
              <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-5 md:gap-6">
                {[
                  {
                    icon: Globe,
                    title: "Network Intelligence",
                    desc: "Analyze the visitor's network characteristics and identify high-risk infrastructure.",
                    items: ["IP Reputation", "ASN Detection", "Datacenter (DCH) Detection", "Residential Network Detection", "Mobile Carrier Detection", "VPN Detection", "Tor Exit Nodes", "Proxy Detection", "Anonymous Network Detection", "Hosting Provider Detection"]
                  },
                  {
                    icon: FileCode2,
                    title: "HTTP Request Analysis",
                    desc: "Inspect every incoming request for anomalies commonly associated with bots and automated tools.",
                    items: ["Suspicious Headers", "Missing Headers", "Header Spoofing", "Invalid Accept Headers", "Invalid Language Headers", "Invalid Encoding", "HTTP Version Anomalies", "Referer Anomalies"]
                  },
                  {
                    icon: Fingerprint,
                    title: "Browser Integrity",
                    desc: "Identify automation frameworks and browsers attempting to impersonate real users.",
                    items: ["Headless Browsers", "Selenium", "Playwright", "Puppeteer", "PhantomJS", "Automation Frameworks", "Navigator Inconsistencies", "WebDriver Detection", "DevTools Detection"]
                  },
                  {
                    icon: Activity,
                    title: "Behavioral Analysis",
                    desc: "Evaluate real user interactions that are difficult for bots to reproduce.",
                    items: ["Mouse Movement", "Scroll Behavior", "Typing Cadence", "Click Timing", "Session Duration", "Navigation Flow", "Interaction Speed", "Idle Time"]
                  },
                  {
                    icon: ShieldCheck,
                    title: "Threat Intelligence",
                    desc: "Leverage continuously updated intelligence to identify known malicious activity before it reaches your application.",
                    items: ["Known Attackers", "Known Scrapers", "Malicious Browser Fingerprints", "VPN Providers", "High-Risk ASNs", "Bot Signatures", "Emerging Threat Indicators"]
                  }
                ].map((layer, i) => (
                  <motion.div
                    key={i}
                    initial={{ opacity: 0, y: 20 }}
                    whileInView={{ opacity: 1, y: 0 }}
                    viewport={{ once: true }}
                    transition={{ duration: 0.5, delay: i * 0.1 }}
                    className="relative bg-white/[0.02] backdrop-blur-xl border border-white/[0.06] rounded-2xl p-6 md:p-7 flex flex-col group transition-all duration-500 hover:-translate-y-1 hover:scale-[1.01] hover:bg-white/[0.04] hover:border-white/[0.12] hover:shadow-[0_20px_40px_-15px_rgba(0,0,0,0.7),0_0_20px_rgba(255,255,255,0.05)] overflow-hidden"
                  >
                    {/* Inner subtle gradient hover effect */}
                    <div className="absolute inset-0 bg-gradient-to-br from-white/[0.05] to-transparent opacity-0 group-hover:opacity-100 transition-opacity duration-500 pointer-events-none"></div>
                    
                    <div className="relative z-10 flex items-center gap-3 mb-5 text-[#FFB300] group-hover:text-[#ffc436] transition-colors duration-300">
                      <layer.icon className="w-6 h-6 md:w-7 md:h-7 shrink-0 drop-shadow-[0_0_10px_rgba(255,179,0,0.3)] group-hover:drop-shadow-[0_0_15px_rgba(255,179,0,0.5)] transition-all duration-300" />
                      <h3 className="text-xl md:text-2xl font-black uppercase tracking-tighter leading-none mt-1 text-white/90 group-hover:text-white transition-colors duration-300">
                        {layer.title}
                      </h3>
                    </div>
                    
                    <p className="relative z-10 text-[#888] text-xs uppercase font-bold tracking-[0.06em] leading-relaxed mb-6 min-h-[3.5rem] group-hover:text-[#a0a0a0] transition-colors duration-300">
                      {layer.desc}
                    </p>
                    
                    <div className="relative z-10 space-y-2.5 mt-auto">
                      {layer.items.map((item, j) => (
                        <div key={j} className="flex items-start gap-2.5">
                          <CheckCircle2 className="w-4 h-4 text-white/40 group-hover:text-[#FFB300]/80 shrink-0 mt-[1px] transition-colors duration-300" />
                          <span className="text-white/70 group-hover:text-white/95 text-xs md:text-[13px] font-semibold uppercase tracking-[0.05em] leading-snug transition-colors duration-300">{item}</span>
                        </div>
                      ))}
                    </div>
                  </motion.div>
                ))}
              </div>
            </div>
          </div>

          {/* Say Goodbye to Click Fraud Section */}
          <div className="bg-[#F2F7F6] py-16 md:py-24 px-6">
            <div className="max-w-[1400px] mx-auto">
              <div className="text-center max-w-3xl mx-auto mb-12 md:mb-16">
                <motion.div
                  initial={{ opacity: 0, y: 20 }}
                  whileInView={{ opacity: 1, y: 0 }}
                  viewport={{ once: true }}
                  transition={{ duration: 0.6 }}
                >
                  <h2 className="text-3xl md:text-4xl lg:text-5xl font-sans font-bold text-[#083038] mb-4 tracking-tight">
                    Say Goodbye to Click Fraud
                  </h2>
                  <p className="text-base md:text-lg text-[#415F63] leading-relaxed font-medium">
                    Stop wasting your advertising budget on fraudulent clicks, fake impressions, and malicious traffic. BotShield continuously monitors and filters invalid activity in real time, helping ensure your campaigns reach genuine users while maximizing your return on ad spend.
                  </p>
                </motion.div>
              </div>

              <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-5 md:gap-6 mb-12">
                {[
                  {
                    title: "Save Money 24/7",
                    desc: "Protect your advertising budget around the clock with automated click fraud detection. BotShield blocks invalid clicks, fake impressions, and malicious traffic before they can drain your campaigns, ensuring your ads are seen by real people—not bots.",
                    icon: Wallet,
                    color: "bg-[#E5F5FE]",
                    iconColor: "text-[#2B6CB0]"
                  },
                  {
                    title: "Customize Your Protection",
                    desc: "Every business faces different threats. Tailor BotShield to your needs with configurable detection rules, including Geo Targeting, Device Detection, Risk Thresholds, IP policies, and other advanced filtering options for greater accuracy.",
                    icon: SlidersHorizontal,
                    color: "bg-[#E9F3ED]",
                    iconColor: "text-[#2C7A7B]"
                  },
                  {
                    title: "Gain Actionable Insights",
                    desc: "Access a comprehensive analytics dashboard that provides visibility into every click and visitor. Monitor campaign health with detailed intelligence such as browser, device, location, ISP, ASN, network type, timestamps, and other valuable security and performance metrics.",
                    icon: PieChart,
                    color: "bg-[#F0EEFF]",
                    iconColor: "text-[#6B46C1]"
                  },
                  {
                    title: "Optimize Campaign Performance",
                    desc: "Use detailed traffic intelligence and behavioral insights to identify suspicious patterns, eliminate wasted spend, and make data-driven decisions that improve campaign effectiveness and overall marketing performance.",
                    icon: Target,
                    color: "bg-[#FFFAF0]",
                    iconColor: "text-[#C05621]"
                  }
                ].map((feature, i) => (
                  <motion.div
                    key={i}
                    initial={{ opacity: 0, y: 20 }}
                    whileInView={{ opacity: 1, y: 0 }}
                    viewport={{ once: true }}
                    transition={{ duration: 0.5, delay: i * 0.1 }}
                    className="bg-white rounded-2xl p-5 md:p-6 flex flex-col hover:shadow-[0_20px_40px_-15px_rgba(8,48,56,0.08)] transition-shadow duration-300 border border-[#083038]/[0.04]"
                  >
                    <div className={`w-full h-32 md:h-40 rounded-xl ${feature.color} flex items-center justify-center mb-6 relative overflow-hidden group`}>
                       <div className="absolute inset-0 bg-gradient-to-br from-white/40 to-transparent opacity-0 group-hover:opacity-100 transition-opacity duration-300"></div>
                       <feature.icon className={`w-10 h-10 md:w-12 md:h-12 ${feature.iconColor} transform group-hover:scale-110 transition-transform duration-300`} strokeWidth={1.5} />
                    </div>
                    <h3 className="text-lg md:text-xl font-bold text-[#083038] mb-3 tracking-tight leading-snug">
                      {feature.title}
                    </h3>
                    <p className="text-[#415F63] leading-relaxed text-sm md:text-[15px]">
                      {feature.desc}
                    </p>
                  </motion.div>
                ))}
              </div>

              <div className="text-center max-w-xl mx-auto">
                 <motion.div
                   initial={{ opacity: 0, y: 20 }}
                   whileInView={{ opacity: 1, y: 0 }}
                   viewport={{ once: true }}
                   transition={{ duration: 0.6, delay: 0.4 }}
                 >
                   <button className="bg-[#083038] hover:bg-[#041a1f] text-white px-6 py-3 rounded-xl font-medium text-base transition-colors duration-200 flex items-center gap-2 mx-auto mb-4 group shadow-xl shadow-[#083038]/20">
                      Get Started for Free
                      <ArrowRight className="w-4 h-4 group-hover:translate-x-1 transition-transform" />
                   </button>
                   <p className="text-[#64848A] text-[13px] md:text-sm">
                     Protect your advertising budget with intelligent click fraud detection in minutes. No credit card required.
                   </p>
                 </motion.div>
              </div>
            </div>
          </div>

          {/* Try It Free Section */}
          <div className="py-12 md:py-16 px-6 border-t border-black/5">
            <div className="max-w-[700px] mx-auto text-center relative z-10">
              <motion.div
                initial={{ opacity: 0, y: 20 }}
                whileInView={{ opacity: 1, y: 0 }}
                viewport={{ once: true }}
                transition={{ duration: 0.6 }}
              >
                <h2 className="text-3xl md:text-4xl lg:text-[2.75rem] font-sans font-medium text-black mb-5 tracking-tight leading-tight">
                  See It in Action — Free
                </h2>
                <p className="text-base md:text-lg text-[#4a4a4a] mb-10 max-w-[600px] mx-auto leading-relaxed">
                  Check any IP address against our complete intelligence pipeline and explore the insights we provide in real time. No credit card, signup, or commitment required—just enter an IP address.
                </p>
                
                <div className="max-w-2xl mx-auto relative group">
                  <div className="absolute -inset-1 bg-black/5 rounded-[1.25rem] blur opacity-0 group-hover:opacity-100 transition duration-500 pointer-events-none"></div>
                  <div className="relative flex flex-col sm:flex-row items-center bg-white rounded-xl p-1.5 shadow-xl transition-all focus-within:ring-4 focus-within:ring-black/10">
                    <input 
                      type="text" 
                      placeholder="Enter IP Address..." 
                      className="w-full bg-transparent border-none text-[#161616] px-6 py-3.5 sm:py-4 outline-none placeholder:text-[#888] text-base font-mono"
                    />
                    <button 
                      type="button" 
                      className="w-full sm:w-auto shrink-0 bg-[#0A0A0A] hover:bg-black text-white px-8 py-3.5 sm:py-4 rounded-lg font-medium transition-all shadow-md flex items-center justify-center gap-2 text-sm tracking-wide active:scale-[0.98]"
                    >
                      <Search className="w-4 h-4" />
                      <span>Analyze IP</span>
                    </button>
                  </div>
                </div>
                
                <div className="mt-8 flex flex-wrap items-center justify-center gap-5 md:gap-8 text-sm text-[#4a4a4a] font-medium">
                  <span className="flex items-center gap-2"><CheckCircle2 className="w-4 h-4 text-emerald-600" /> No credit card required</span>
                  <span className="flex items-center gap-2"><CheckCircle2 className="w-4 h-4 text-emerald-600" /> Instant intelligence</span>
                  <span className="flex items-center gap-2"><CheckCircle2 className="w-4 h-4 text-emerald-600" /> Zero commitment</span>
                </div>
              </motion.div>
            </div>
          </div>
        </div>
      </section>

    

    

      {/* Footer */}
      <footer className="border-t border-white/5 py-12 px-6 mt-auto">
        <div className="max-w-7xl mx-auto flex flex-col md:flex-row items-center justify-between gap-6">
          <div className="flex items-center gap-2 text-slate-400">
            <ShieldCheck className="w-5 h-5" />
            <span className="font-display font-medium">EdgeGuard</span>
          </div>
          <div className="flex gap-6 text-sm text-slate-500">
            <a href="#" className="hover:text-white transition-colors">Documentation</a>
            <a href="#" className="hover:text-white transition-colors">Terms of Service</a>
            <a href="#" className="hover:text-white transition-colors">Privacy Policy</a>
          </div>
          <p className="text-sm text-slate-600">© 2026 EdgeGuard Inc. All rights reserved.</p>
        </div>
      </footer>
    </div>
  );
}
